const app = document.getElementById("app");
app.innerHTML = "<p>Bem-vindo ao Click Suply!</p>";

// Aqui virá o código para cadastro de catálogo, requisições, histórico, etc.